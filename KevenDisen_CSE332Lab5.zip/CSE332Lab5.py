import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.express as px
import pandas as pd
from dash.dependencies import Input, Output
import numpy as np


cor = df = pd.read_csv('CSE332Covid.csv')
df.insert(loc=0, column='State', value=df.index.values)
state = df.drop(columns=['pending'])
state = state.drop(columns=['State', 'Unnamed: 0'])
USstate_abb = {
    'AL': 'Alabama',
    'AS': 'American Samoa',
    'AK': 'Alaska',
    'AZ': 'Arizona',
    'AR': 'Arkansas',
    'CA': 'California',
    'CO': 'Colorado',
    'CT': 'Conneticut',
    'DE': 'Delaware',
    'DC': 'District of Columbia',
    'FL': 'Florida',
    'GA': 'Georgia',
    'HI': 'Hawaii',
    'ID': 'Idaho',
    'IL': 'Illinois',
    'IN': 'Indiana',
    'IA': 'Iowa',
    'KS': 'Kansas',
    'KY': 'Kentucky',
    'LA': 'Lousiana',
    'ME': 'Maine',
    'MD': 'Maryland',
    'MA': 'Massachusetts',
    'MI': 'Michigan',
    'MN': 'Minnesota',
    'MS': 'Mississippi',
    'MO': 'Missouri',
    'MT': 'Montana',
    'NE': 'Nebraska',
    'NV': 'Nevada',
    'NH': 'New Hampshire',
    'NJ': 'New Jersey',
    'NM': 'New Mexico',
    'NY': 'New York',
    'NC': 'North Carolina',
    'ND': 'North Dakota',
    'MP': 'Northern Mariana Islands',
    'OH': 'Ohio',
    'OK': 'Oklahoma',
    'OR': 'Oregon',
    'PW': 'Palau',
    'PA': 'Pennsylvania',
    'PR': 'Puerto Rico',
    'RI': 'Rhode Island',
    'SC': 'South Carolina',
    'SD': 'South Dakota',
    'TN': 'Tennessee',
    'TX': 'Texas',
    'UT': 'Utah',
    'VT': 'Vermont',
    'VI': 'Virgin Islands',
    'VA': 'Virginia',
    'WA': 'Washington',
    'WV': 'West Virginia',
    'WI': 'Wisconsin',
    'WY': 'Wyoming',
}

cor['state'] = cor['state'].map(lambda x: USstate_abb[x] if x in list(USstate_abb.keys()) else x)

cor = df.drop(columns=['date', 'state', 'Unnamed: 0', 'State', 'pending'])

# fill the NaN with 0
cor['death'] = cor['death'].fillna(0)
cor['recovered'] = cor['recovered'].fillna(0)
cor['positive'] = cor['positive'].fillna(0)
cor['hospitalizedcurrently'] = cor['hospitalizedcurrently'].fillna(0)

# heatmap
correlate1 = cor.corr()
heatmap = px.imshow(correlate1, origin='lower', zmin=-1, title="Correlation Matrix")

#Map
mapUS = state.groupby(by='state', as_index=False).agg('sum')


print(mapUS)

setBarData = mapUS
setBarData = setBarData.drop(columns=['positive', 'negative', 'death'])
print(setBarData)
#Setting up Bar Graph with linked Map
hospinc = 0
for i in range(setBarData['hospitalizedcurrently'].count()):
    hospinc += setBarData['hospitalizedcurrently'].count()
posinc = 0
for i in range(setBarData['positiveincrease'].count()):
    posinc += setBarData['positiveincrease'].iloc[i]
neginc = 0
for i in range(setBarData['negativeincrease'].count()):
    neginc += setBarData['negativeincrease'].iloc[i]

deathinc = 0
for i in range(setBarData['deathincrease'].count()):
    deathinc += setBarData['deathincrease'].iloc[i]
barData = pd.DataFrame()

values = [posinc, neginc, deathinc, hospinc]
names = ['positiveincrease', 'negativeincrease', 'deathincrease', 'hospitalizedcurrently']
barData['Names'] = names
barData['Values'] = values
barData['Values'] = np.log10(barData['Values'])
bar = px.bar(barData, x=barData['Names'], y=barData['Values'],
             labels={'Names': 'Impact', 'Values': 'Values Log 10'},
             title="Covid-19 Impact in the entire United States")


# Dash
app = dash.Dash()
app.layout = html.Div(children=[
    html.H1("Keven Disen's CSE 332 Lab 5"),
    html.P("Welcome to my CSE 332 Lab 5 WebServer", style={'text-align': 'center'}),
    html.Div(children=[
        dcc.Graph(id='heat', figure=heatmap, style={'height':'450px', 'width':'450px', "display":"inline-block"}),
        dcc.Graph(id='Scatter', style={'height':'550px', 'width':'550px', "display":"inline-block"}),
    ],style={'text-align':'center'}),
    html.Div(children=[
        dcc.Graph(id='bar', figure=bar,style={'height':'450px', 'width':'450px', "display":"inline-block"} ),
        dcc.Graph(id='mapBar', style={'height':'600px', 'width':'600px', "display":"inline-block"})],
        style={'text-align':'center'})
    ])

#Correlation linked with Scatter
@app.callback(
    Output('Scatter', 'figure'),
    Input('heat', 'hoverData')
)
def update_scatter(hoverData):
    if not hoverData:
        return {}
    else:
        x = hoverData['points'][0]["x"]
        y = hoverData['points'][0]["y"]
        fig = px.scatter(cor, x=x, y=y, hover_name="positive",color='positive', color_continuous_scale=px.colors.sequential.Agsunset,
                         hover_data=["positive", "negative", "death"], title="Linked Covid-19 Scatter Correlation")
    return fig

#Bar linked with Map
@app.callback(
    Output('mapBar', 'figure'),
    Input('bar', 'hoverData')
)
def pie_update(hoverData):
    if not hoverData:
        return {}
    else:
        val = hoverData['points'][0]["x"]
        fig = px.choropleth(setBarData, locations=setBarData['state'],
                            locationmode="USA-states",
                            color=val,
                            color_continuous_scale=px.colors.sequential.Hot,
                            scope="usa",
                            hover_name=setBarData['state'], hover_data={'state':True, val:True},
                            title=val+" covid-19 cases in US")
        # fig = px.pie(setBarData, values=val, names=setBarData['state'],
        #              title=val + " covid-19 cases in each state")
    return fig




if __name__ == '__main__':
    app.run_server(debug=True)
