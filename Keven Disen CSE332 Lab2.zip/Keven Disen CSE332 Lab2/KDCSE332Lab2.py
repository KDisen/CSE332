"""
Keven Disen
111433335
CSE 332
Lab 2
10/1/2020
"""

import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.express as px
import pandas as pd
from dash.dependencies import Input, Output

df = pd.read_csv('CSE332Covid.csv')
df.insert(loc=0, column='State', value=df.index.values)
df3 = df.drop(columns=['pending'])

USstate_abb = {
    'AL': 'Alabama',
    'AS': 'American Samoa',
    'AK': 'Alaska',
    'AZ': 'Arizona',
    'AR': 'Arkansas',
    'CA': 'California',
    'CO': 'Colorado',
    'CT': 'Conneticut',
    'DE': 'Delaware',
    'DC': 'District of Columbia',
    'FL': 'Florida',
    'GA': 'Georgia',
    'HI': 'Hawaii',
    'ID': 'Idaho',
    'IL': 'Illinois',
    'IN': 'Indiana',
    'IA': 'Iowa',
    'KS': 'Kansas',
    'KY': 'Kentucky',
    'LA': 'Lousiana',
    'ME': 'Maine',
    'MD': 'Maryland',
    'MA': 'Massachusetts',
    'MI': 'Michigan',
    'MN': 'Minnesota',
    'MS': 'Mississippi',
    'MO': 'Missouri',
    'MT': 'Montana',
    'NE': 'Nebraska',
    'NV': 'Nevada',
    'NH': 'New Hampshire',
    'NJ': 'New Jersey',
    'NM': 'New Mexico',
    'NY': 'New York',
    'NC': 'North Carolina',
    'ND': 'North Dakota',
    'MP': 'Northern Mariana Islands',
    'OH': 'Ohio',
    'OK': 'Oklahoma',
    'OR': 'Oregon',
    'PW': 'Palau',
    'PA': 'Pennsylvania',
    'PR': 'Puerto Rico',
    'RI': 'Rhode Island',
    'SC': 'South Carolina',
    'SD': 'South Dakota',
    'TN': 'Tennessee',
    'TX': 'Texas',
    'UT': 'Utah',
    'VT': 'Vermont',
    'VI': 'Virgin Islands',
    'VA': 'Virginia',
    'WA': 'Washington',
    'WV': 'West Virginia',
    'WI': 'Wisconsin',
    'WY': 'Wyoming',
}

df3['state'] = df3['state'].map(lambda x: USstate_abb[x] if x in list(USstate_abb.keys()) else x)

mainData = df3.drop(df3.columns[1], 1)

mainData['death'] = mainData['death'].fillna(0)
mainData['recovered'] = mainData['recovered'].fillna(0)
mainData['positive'] = mainData['positive'].fillna(0)

mainData = mainData.drop(columns=['State'])

stateDeath = mainData
stateDeath = stateDeath.groupby(stateDeath['state']).agg(sum)
statePositive = stateDeath
statePositive = statePositive.sort_values(by=['positiveincrease'], ascending=False)
# print(statePositive)
stateDeath = stateDeath.sort_values(by=['deathincrease'], ascending=False)


positiveList = []
stateList2 = []
for i in range(5):
    positiveList.append(statePositive['positiveincrease'].iloc[i])
# print(positiveList)
for i in statePositive['positiveincrease'].index[0:5]:
    stateList2.append(i)
# print(stateList2)
positive = 0
for i in range(statePositive['positiveincrease'].count()):
    if i > 5:
        positive += statePositive['positiveincrease'].iloc[i]
# print(positive)
stateList2.append("Other")
positiveList.append(positive)
pieStatePosInc = pd.DataFrame()
pieStatePosInc['Names'] = stateList2
pieStatePosInc['Positive'] = positiveList

deathList = []
stateList = []
for i in range(5):
    deathList.append(stateDeath['deathincrease'].iloc[i])
# print("death increase", deathList)
for i in stateDeath['deathincrease'].index[0:5]:
    stateList.append(i)
# print(stateList)
death = 0
for i in range(stateDeath['deathincrease'].count()):
    if i > 5:
        death += stateDeath['deathincrease'].iloc[i]

deathList.append(death)
stateList.append("Other")
pieStateDeath = pd.DataFrame()
pieStateDeath['Names'] = stateList
pieStateDeath['Death Amount'] = deathList
# print(pieStateDeath)

app = dash.Dash()

app.layout = html.Div(children=[
    html.H1("Keven Disen's CSE 332 Lab 2"),
    html.P("Welcome to my CSE 332 Lab 2 WebServer", style={'text-align':'center'}),
    html.P("For Lab 2, I created 4 different graphs to show the data I have selected. "
           "In these graphs, you will be able to choose different variables for the respective axis.",
           style={'text-align':'center'}),

    # Bar Graph and Histogram
    dcc.Tabs(id='tab1', children=[
        dcc.Tab(label='Bar Graph & Histogram', value='tab1', children=[
            dcc.Graph(id='bar'),
            html.P('X-axis: ', style={'display': 'inline-block', 'margin-left': '150px'}),
            dcc.Dropdown(id='selectX',
                         value='state',
                         options=[{'label': 'State', 'value': 'state'},
                                  {'label': 'Date', 'value': 'date'},
                                  {'label': 'Date 2', 'value': 'deathincrease'}],
                         style={'width': '200px', 'display': 'inline-block', 'margin-right': '150px'}),

        ]),
        #Pie Chart
        dcc.Tab(label='Pie Chart', value='tab2', children=[
            dcc.Graph(id='pie'),
            html.P('Variable: ', style={'display': 'inline-block', 'margin-left': '200px'}),
            dcc.Dropdown(id='Catx',
                         value='Death Amount',
                         options=[{'label': 'Death Amount', 'value': 'Death Amount'},
                                  {'label': 'Positive', 'value': 'Positive'}],
                         style={'width': '200px', 'display': 'inline-block', 'margin-right': '150px'}),
        ]),
        #Scatter Plot
        dcc.Tab(label='Scatter Plot', value='tab3', children=[
            dcc.Graph(id='scatter'),
            html.P('X-axis: ', style={'display': 'inline-block', 'margin-left': '100px'}),
            dcc.Dropdown(id='scatterX',
                         value='positive',
                         options=[{'label': 'Positive', 'value': 'positive'},
                                  {'label': 'Negative', 'value': 'negative'}],
                         style={'width': '200px', 'display': 'inline-block', 'margin-right': '100px'}),
            html.P('Y-axis: ', style={'display': 'inline-block', 'margin-left': '100px'}),
            dcc.Dropdown(id='scatterY',
                         value='death',
                         options=[{'label': 'Death', 'value': 'death'},
                                  {'label': 'Recovered', 'value': 'recovered'}],
                         style={'width': '200px', 'display': 'inline-block', 'margin-right': '100px'}),

            #Body Paragraph


        ])])])


@app.callback(
    Output('bar', 'figure'),
    Input('selectX', 'value')
)
def updateBar(selection):
    if selection == "state":
        fig = px.bar(mainData,
                     x=mainData[selection].unique(),
                     y=mainData['state'].value_counts(),
                     log_y=True,
                     title='Amount of days State tested people for CoVid-19',
                     labels={'x': 'States', 'y': 'Days'})


    elif selection == 'date':
        fig = px.bar(mainData,
                     x=mainData[selection].unique(),
                     y=mainData['date'].value_counts(),
                     title='Amount of States that tested for CoVid-19',
                     labels={'x': 'Dates', 'y': 'Amount of States'})
    else:
        fig = px.histogram(mainData,
                           x=mainData['date'],
                           y=mainData[selection],
                           title='Deaths By Date',
                           labels={'x': 'Dates', 'y': 'Deaths'})

    return fig


@app.callback(
    Output('pie', 'figure'),
    Input('Catx', 'value')
)
def updatePie(selectionX):
    if selectionX == "Death Amount":
        fig = px.pie(pieStateDeath,
                     values=pieStateDeath[selectionX],
                     names=pieStateDeath['Names'],
                     title='States with High Death Cases')
    else:
        fig = px.pie(pieStatePosInc,
                     values=pieStatePosInc[selectionX],
                     names=pieStatePosInc['Names'],
                     title='States with High Positive Cases',
                     )
    return fig


@app.callback(
    Output('scatter', 'figure'),
    [Input('scatterX', 'value'),
     Input('scatterY', 'value')]
)
def updateScatter(sX, sY):
    if sX == 'positive':
        fig = px.scatter(mainData,
                         x='positive',
                         y=sY,
                         title='Positive vs ' + sY,
                         labels={'x': 'Positive', 'y': 'Death'})
    else:
        fig = px.scatter(mainData, x=sX, y=sY, title='Negative vs ' + sY)

    return fig


if __name__ == '__main__':
    app.run_server(debug=True)

# dcc.Dropdown is to select different variables for x and y axis
# dcc.Tab can use this to do the different graphs
